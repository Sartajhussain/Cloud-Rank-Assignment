import React from 'react'

function SelectUser({message} ) {
  return (
    <>
    <div className='select-user'>
        <h3>{message}</h3>
    </div>
    </>
  )
}

export default SelectUser